package controle;

public class FuncionarioController {

}
